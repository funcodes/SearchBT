﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;
namespace 测试种子搜索
{
    public partial class Form1 : Form
    {
       bool stop = false;
        public Form1()
        {
            //by:Toto;
            //totomike@163.com;
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
           
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            
                // listView1.Items.Add("");
                // listView1.Items.Clear();
                // tabControl1.TabPages.Remove(tabControl1.TabPages);
                // button1.Text = "停止搜索";



            if (stop == false)
            {
                // button1.Enabled = false;
               // Thread xiancheng = new Thread(new ThreadStart(kaishi));//此线程用于检测是否为番号，如果为番号则打开另一个搜索页面
               // xiancheng.Start();
                Thread sousuo = new Thread(new ThreadStart(shuchu));//此线程用于在列表中输出搜索结果
                sousuo.Start();
            }
            else { 
            
            }
            
               

        } 
       /* private void kaishi()
        {
            try
            {
                
                //string url1 = "https://btdigg.org/search?info_hash=&q=" + textBox1.Text;
                //string url2="http://av.nightlife141.com/?keyword="+textBox1.Text;

                // string webData1=GetText(url1 );
                //   string webData2=GetText(url2 );
                // string wy1=GetInfo(webData1);
                // string wy2=GetInfo(webData2);
               
                Regex fanhao = new Regex("^[a-zA-Z]{1,9}[^\\w]*[0-9]{0,9}$");//检测用户输入的是否为番号
                Match m = fanhao.Match(textBox1.Text);
                if (m.Success)
                {
                   // tabControl1.TabPages.Remove(Mytabpage);
                   // if(tabControl1.Controls.Find("Mytabpage",false).Count())
                    string Title = "网页";
                    TabPage Mytabpage = new TabPage(Title);
                    //bControl1.TabPages.Add(Mytabpage);
                    //tabControl1.TabPages.Remove(tabControl1);

                }


               
            }


            catch
            {
                MessageBox.Show("没有搜索到内容");
            }
            

        }*/
        private void shuchu() {

            try
            {

                string url = "http://www.btcherry.com/search?keyword=" + textBox1.Text.Trim();
                //  GetInfo(url1);

                string webdata = GetText((string)url);        //webdata是搜索页面的数据，主要用于确定总共有多少页
                Regex rex = new Regex("(?<=totalPages: )([^,]+)");
                Match mch = rex.Match(webdata);
                int Totalpages = int.Parse(mch.ToString());
                //  ListViewItem item = new ListViewItem();//din
                
                    for (int i = 1; i <= Totalpages; i++)
                    {
                        string url1 = "http://www.btcherry.com/search?keyword=" + textBox1.Text + "&p=" + i.ToString();
                        string wy = GetText((string)url1);        //wy是搜索页面的数据，主要用于确定子网页，进入子网页之后正则出想要的数据
                        Regex r = new Regex("(?!<div class=\"r\">[^>]+)(?<=<a href=\")/torrent(\\S+)(?=\" target)");
                  
                         foreach (Match firstm in r.Matches(wy))//firstm是初次正则之后的网址
                        {
                            // Console.WriteLine(m.Value);
                            // MessageBox.Show(m.Value);
                            string url2 = "http://www.btcherry.com/" + firstm.Value;  //url2 是点击之后的网址
                            // Console.WriteLine(url2+"aaaaaaaaaa");
                            string wb = GetText(url2);



                            ListViewItem list = new ListViewItem((listView1.Items.Count + 1).ToString());
                            list.SubItems.Add(Regex.Match(wb, "(?<=<title>)([^\"]+?)(?= - 磁力)").Value);//获取标题
                            list.SubItems.Add(Regex.Match(wb, "(?<=大小：</span>)([^</span]+)").Value);//获取大小
                            list.SubItems.Add(Regex.Match(wb, "(?<=color: #333;\">)([^<]+)").Value);//获取详细内容
                            list.SubItems.Add(Regex.Match(wb, "(?<=#1e0fbe;\">)magnet([^<]+?)(?=</a>)").Value);//获取磁链
                            listView1.Items.Add(list);
                            /*   progressBar1.Minimum = 0;
                               progressBar1.Maximum = 100;
                               progressBar1.Step = 1;
                               for (int a = 0; a < 100; a++)
                               {
                                   progressBar1.PerformStep();
                               }
                               if (textBox1.Text == "")
                               {
                                   MessageBox.Show("请输入要搜索的内容");
                               }*/


                        }

               
                } 
            }
            catch
            {
                MessageBox.Show("出现错误,请检查网络是否通畅或升级到.NET Framework4.0");
                button1.Enabled = true;
            }

            
            
        
        }



        private void GetInfo(object url1)    //url1是搜索页面的网址
        {
           
        }

              private string GetText(string url, Encoding encoding = null)
        {
            try
            {
                byte[] buf = new WebClient().DownloadData(url);
                if (encoding != null) return encoding.GetString(buf);
                string html = Encoding.UTF8.GetString(buf);
                encoding = GetEncoding(html);
                if (encoding == null || encoding == Encoding.UTF8) return html;
                return encoding.GetString(buf);
            }
            catch { return ""; }
        }
        static Encoding GetEncoding(string html)
        {
            string pattern = @"(?i)\bcharset=(?<charset>[-a-zA-Z_0-9]+)";
            string charset = Regex.Match(html, pattern).Groups["charset"].Value;
            try { return Encoding.GetEncoding(charset); }
            catch (ArgumentException) { return null; }
        }

       
      /*  public class  CreatLabel
        {
            Label lab = new Label();
            
     
         
         }*/

       

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click_1(object sender, EventArgs e)
        {
           
        }

        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
           

        }
        private void listView1_DoubleClick(object sender, EventArgs e)  //双击listview
        {
            Clipboard.SetDataObject(listView1.SelectedItems[0].SubItems[4].Text);
          //MessageBox.Show("success");
          //  listView1.SelectedItems[0].SubItems[4].Text;  //获取所选行的磁链
          //  MessageBox.Show(listView1.SelectedItems[0].SubItems[4].Text);
          //  MessageBox.Show(listView1.SelectedItems[0].SubItems[3].Text);
            try
            {
                RegistryKey reg = null;
                reg = Registry.CurrentUser.OpenSubKey("Software", true).OpenSubKey("Thunder Network", true).OpenSubKey("Thunder", true);
               // reg = Registry.CurrentUser.OpenSubKey("Software\\Thunder Network\\Thunder", true);//获取迅雷的安装地址

                                           //打开迅雷
                if (reg.GetValue("Path") != null)//有安装迅雷
                {
                    Process.Start(@reg.GetValue("Path").ToString());

                    if (reg.GetValue("Path") == null)
                    {

                        reg = Registry.CurrentUser.OpenSubKey("Software\\Tencent\\QQDownload", true);//获取旋风的安装地址

                        Process.Start(@reg.GetValue("Exe").ToString());//打开旋风
                    }
                      
               }
               

               // MessageBox.Show(reg.GetValue("Path").ToString());

               /* reg = Registry.CurrentUser;
                RegistryKey OpenKey = reg.OpenSubKey("\\Software\\Thunder Network\\Thunder\\Path", true);
                string Key = OpenKey.GetValue("Path").ToString();
               // MessageBox.Show(Key);
               // Console.WriteLine(Key);
                */


            }
            catch
            {
                MessageBox.Show("请安装迅雷或其他搜索软件");
            }
        }

        private void listView1_SelectedIndexChanged_2(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
         /*   RegistryKey rsk = null;  ///rsk是QQ的注册表地址
            rsk = Registry.CurrentUser.OpenSubKey("Software\\Tencent\\PlatForm_Type_List\\1");
            Process.Start(@rsk.GetValue("TypePath").ToString());*/
            MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
            DialogResult dr = MessageBox.Show("同开发者QQ：1014281072联系吗？", "", messButton);
            if (dr == DialogResult.OK)
            {
                System.Diagnostics.Process.Start("http://wpa.qq.com/msgrd?v=3&uin=1014281072&site=qq&menu=yes");

            }
                
           
            
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            stop = true;
          //  button1.Enabled = true;
        }

     
        }

        
    }

